export default [
  {
    name: "Max",
    breed: "husky",
    img: "https://dog.ceo/api/img/husky/n02110185_1469.jpg"
  },
  {
    name: "Rusty",
    breed: "shiba",
    img: "https://dog.ceo/api/img/shiba/shiba-13.jpg"
  },
  {
    name: "Rocco",
    breed: "boxer",
    img: "https://dog.ceo/api/img/boxer/n02108089_14112.jpg"
  },
  {
    name: "Zoey",
    breed: "beagle",
    img: "https://dog.ceo/api/img/beagle/n02088364_11136.jpg"
  },
  {
    name: "Duke",
    breed: "doberman",
    img: "https://dog.ceo/api/img/doberman/n02107142_4653.jpg"
  },
  {
    name: "Lily",
    breed: "malamute",
    img: "https://dog.ceo/api/img/malamute/n02110063_1104.jpg"
  },
  {
    name: "Winston",
    breed: "pug",
    img: "https://dog.ceo/api/img/pug/n02110958_15626.jpg"
  },
  {
    name: "Angel",
    breed: "samoyed",
    img: "https://dog.ceo/api/img/samoyed/n02111889_4470.jpg"
  }
];
